#!/usr/bin/env bash
# Double-click this file in Finder to run the installer in Terminal.
cd "$(dirname "$0")" || exit 1
/bin/bash ./install.sh
echo
read -r -p "Press Return to close this window…" _
