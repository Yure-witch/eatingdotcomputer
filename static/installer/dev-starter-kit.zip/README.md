# Dev Starter Kit (macOS)

One-shot installer for a Mac software-development setup. Safe to re-run — anything already installed is skipped, and a summary at the end lists what was installed, skipped, or failed.

## What it installs

| Tool | Source |
|---|---|
| Claude Code | official installer (`claude.ai/install.sh`) |
| VS Code | `visual-studio-code` cask |
| Python 3.13 | `python@3.13` |
| uv (Python package manager) | `uv` |
| opencode | `opencode` |
| Antigravity | `antigravity` cask |
| GitHub Desktop | `github` cask |
| Google Chrome | `google-chrome` cask |
| Node.js (+ npm) | `node` |
| Git | `git` |
| Homebrew, Xcode CLT | prerequisites |

**Python packages**

- **Command-line tools** (`python-tools.txt`), installed globally with `uv tool install`: ruff, black, mypy, ipython, jupyterlab, pre-commit, httpie, poetry.
- **Libraries** (`python-packages.txt`), installed into a shared starter environment at `~/.venvs/dev`: requests, httpx, python-dotenv, pydantic, rich, typer, numpy, pandas, matplotlib, pillow, beautifulsoup4, sqlalchemy, fastapi, uvicorn, flask, pytest, ipykernel. It's also registered as the Jupyter kernel **"Python (dev)"**.

To change the list, edit the two `.txt` files.

## Run it

Paste this into Terminal:

```bash
curl -fsSL https://www.eating.computer/installer/install.sh | bash
```

Or from the unzipped kit: double-click `Install Dev Tools.command` (the first time, right-click → Open to get past Gatekeeper), or run `bash install.sh`.

It will ask for your password (Homebrew needs it) and may pop up the Xcode Command Line Tools installer.

## After installing

1. Open a new terminal window so PATH changes take effect.
2. `claude` → sign in. `opencode` → choose a provider.
3. Open GitHub Desktop → sign in.
4. Python: `source ~/.venvs/dev/bin/activate`. For real projects, prefer a per-project env: `uv init myproject && cd myproject && uv add requests`.
