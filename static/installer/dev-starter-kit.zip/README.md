# Dev Starter Kit (macOS)

One-shot installer for a Mac software-development setup. No Homebrew, no Xcode Command Line Tools, no password — every app comes from its vendor's own download, and command-line tools go in `~/.local`. Safe to re-run — anything already installed is skipped, and a summary at the end lists what was installed, skipped, or failed.

## What it installs

| Tool | Source |
|---|---|
| Claude Code | official installer (`claude.ai/install.sh`) |
| VS Code | Microsoft download (universal) |
| Antigravity | Google download (link from Homebrew's public cask API) |
| GitHub Desktop | GitHub download |
| Google Chrome | Google download (universal) |
| Git | the git bundled inside GitHub Desktop, exposed as `~/.local/bin/git` |
| Node.js 24 LTS | nodejs.org tarball → `~/.local/node` |
| uv + Python 3.13 | astral.sh installer; Python via `uv python install` |
| opencode | official installer (`opencode.ai/install`) |

Apps go in `/Applications` (or `~/Applications` on a non-admin account). The four app downloads run in parallel.

**Python packages**

- **Command-line tools** (`python-tools.txt`), installed globally with `uv tool install`: ruff, black, mypy, ipython, jupyterlab, pre-commit, httpie, poetry.
- **Libraries** (`python-packages.txt`), installed into a shared starter environment at `~/.venvs/dev`: requests, httpx, python-dotenv, pydantic, rich, typer, numpy, pandas, matplotlib, pillow, beautifulsoup4, sqlalchemy, fastapi, uvicorn, flask, pytest, ipykernel. It's also registered as the Jupyter kernel **"Python (dev)"**.

To change the list, edit the two `.txt` files.

## Run it

Paste this into Terminal:

```bash
curl -fsSL https://www.eating.computer/installer/install.sh | bash
```

Or from the unzipped kit: double-click `Install Dev Tools.command` (the first time, right-click → Open to get past Gatekeeper), or run `bash install.sh`.

## After installing

1. Open a new terminal window so PATH changes take effect.
2. `claude` → sign in. `opencode` → choose a provider.
3. Open GitHub Desktop → sign in.
4. Python: `source ~/.venvs/dev/bin/activate`. For real projects, prefer a per-project env: `uv init myproject && cd myproject && uv add requests`.
