# Dev Starter Kit (macOS)

One-shot installer for a Mac software-development setup.

- **Homebrew, without the Xcode Command Line Tools.** Homebrew's official installer insists on them, so this unpacks Homebrew directly and only installs prebuilt bottles and casks, which don't need a compiler.
- **Needs your password once**, at the start (admin account required).
- **Checks its own work and re-runs** until everything is actually installed (up to 5 passes). Anything Homebrew can't provide falls back to the vendor's own download.

## What it installs

| Tool | Homebrew | Fallback |
|---|---|---|
| Homebrew | unpacked to `/opt/homebrew` | — |
| Git | `git` | GitHub Desktop's bundled git |
| Node.js | `node` | nodejs.org 24 LTS → `~/.local/node` |
| uv | `uv` | astral.sh installer |
| Python 3.13 | `python@3.13` | `uv python install` |
| opencode | `opencode` | opencode.ai installer |
| Claude Code | — | official installer (`claude.ai/install.sh`) |
| VS Code | `visual-studio-code` cask | Microsoft download |
| Google Chrome | `google-chrome` cask | Google download |
| GitHub Desktop | `github` cask | GitHub download |
| Antigravity | `antigravity` cask | Google download |

**Python packages**

- **Command-line tools** (`python-tools.txt`), installed globally with `uv tool install`: ruff, black, mypy, ipython, jupyterlab, pre-commit, httpie, poetry.
- **Libraries** (`python-packages.txt`), installed into a shared starter environment at `~/.venvs/dev`: requests, httpx, python-dotenv, pydantic, rich, typer, numpy, pandas, matplotlib, pillow, beautifulsoup4, sqlalchemy, fastapi, uvicorn, flask, pytest, ipykernel. It's also registered as the Jupyter kernel **"Python (dev)"**.

To change the list, edit the two `.txt` files.

## Run it

Paste this into Terminal:

```bash
curl -fsSL https://www.eating.computer/installer/install.sh | bash
```

Or from the unzipped kit: double-click `Install Dev Tools.command` (the first time, right-click → Open to get past Gatekeeper), or run `bash install.sh`.

## After installing

1. Open a new terminal window so PATH changes take effect.
2. `claude` → sign in. `opencode` → choose a provider.
3. Open GitHub Desktop → sign in.
4. Python: `source ~/.venvs/dev/bin/activate`. For real projects, prefer a per-project env: `uv init myproject && cd myproject && uv add requests`.
